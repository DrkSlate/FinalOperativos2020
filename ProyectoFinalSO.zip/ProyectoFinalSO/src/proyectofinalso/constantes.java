/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectofinalso;

/**
 *
 * @author richardgarcia
 */
public class constantes {
        public static final String carro_abajo = "/images/rojo_abajo.png";
	public static final String carro_arriba ="/images/rojo_arriba.png";
	public static final String carro_izq = "/images/rojo_izquierda.png";
	public static final String carro_der = "/images/rojo_derecha.png";
        public static final String carro_med = "/images/rojo_derecha.png";
}
